date_of_birth = input('Enter your name: ')

date_of_birth = int(date_of_birth)

age = 2023 - date_of_birth

response = f'You are {age} years old this year'

print(response)

from django.contrib import admin
from .models import UsersData, Contact

# Register your models here.

admin.site.register(UsersData)
admin.site.register(Contact)
